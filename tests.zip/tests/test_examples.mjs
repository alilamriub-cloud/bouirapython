import { makeRuntime } from './helpers/harness.mjs';
import { CHAPTERS, ALL_EXAMPLES, exampleFileName, SHADOWING } from '../www/js/examples.js';
import { test, eq, ok, done } from './lib.mjs';
eq(CHAPTERS.length, 21);
for (const c of CHAPTERS) { ok(c.title.en && c.title.fr && c.title.ar, 'titles ' + c.id); ok(c.examples.length >= 1); }
const q = []; const { rt, log } = makeRuntime({ live: true, onNeed: (p, r) => r.submitInput(q.shift() ?? '') });
await rt.start();
for (const ex of ALL_EXAMPLES) {
  await test(`example ${ex.chapter}/${ex.id}`, async () => {
    log.out = ''; log.err = ''; log.plots = []; q.length = 0; q.push(...(ex.inputs || []));
    const r = await rt.run({ code: ex.code, filename: exampleFileName(ex), files: { [exampleFileName(ex)]: ex.code } });
    ok(r.ok, log.err); ok(!/Traceback/.test(log.err), log.err); ok(log.out.length > 0 || log.plots.length > 0, 'no output');
    if (/plt\.show\(\)/.test(ex.code)) ok(log.plots.length >= 1, 'expected a figure');
  });
}
ok(ALL_EXAMPLES.every(e => !SHADOWING.has(exampleFileName(e).replace(/\.py$/, ''))));
rt.w.terminate(); done();
