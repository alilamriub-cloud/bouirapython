import { Worker } from 'node:worker_threads';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Runtime } from '../../www/js/runtime.js';
const here = path.dirname(fileURLToPath(import.meta.url));
export const BASE = path.resolve(here, '../../www') + '/';

export function nodeWorker() {
  const w = new Worker(path.join(here, 'worker_boot.cjs'));
  const a = { postMessage: (m) => w.postMessage(m), terminate: () => w.terminate(), onmessage: null, onerror: null };
  w.on('message', (d) => a.onmessage && a.onmessage({ data: d }));
  w.on('error', (e) => a.onerror && a.onerror(e));
  return a;
}

/** A Runtime plus a scripted "student" that answers input() prompts. */
export function makeRuntime({ live = true, answers = [], onNeed } = {}) {
  const log = { out: '', err: '', plots: [], changes: {}, prompts: [], states: [], resets: 0 };
  let rt;
  const queue = [...answers];
  rt = new Runtime({
    base: BASE, createWorker: nodeWorker, isolated: live,
    on: {
      stdout: (t) => (log.out += t), stderr: (t) => (log.err += t), plot: (png, svg) => log.plots.push({ png, svg }),
      state: (s) => log.states.push(s), changes: (c) => (log.changes = c), reset: () => { log.resets++; log.out = ''; log.err = ''; log.plots = []; },
      needInput: (p) => { log.prompts.push(p); setTimeout(() => { if (onNeed) onNeed(p, rt); else rt.submitInput(queue.length ? queue.shift() : ''); }, 5); },
    },
  });
  return { rt, log };
}
