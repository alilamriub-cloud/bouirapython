package dz.univbouira.pythonstudio

import android.annotation.SuppressLint
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.view.ViewGroup
import android.webkit.*
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader

/**
 * Thin shell around the web app in assets/ (same files as the browser/PWA version).
 *  - serves assets from https://appassets.androidplatform.net/assets/ (no network, no INTERNET permission)
 *  - adds COOP/COEP headers so the page can be cross-origin isolated when the installed WebView supports it
 *    (otherwise the app automatically uses its "compatibility" input mode, see README)
 *  - exposes ONE minimal bridge method (exportFile) for saving files through the system "Save as" dialog
 *  - lets <input type=file> open the system picker
 */
class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private var chooserCallback: ValueCallback<Array<Uri>>? = null
    private var pendingName: String? = null
    private var pendingBytes: ByteArray? = null

    private val pickFiles = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        chooserCallback?.onReceiveValue(uris.toTypedArray()); chooserCallback = null
    }
    private val saveFile = registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val bytes = pendingBytes; pendingBytes = null; pendingName = null
        if (uri != null && bytes != null) try {
            contentResolver.openOutputStream(uri, "wt")?.use { it.write(bytes) }
            Toast.makeText(this, "✓", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, e.message, Toast.LENGTH_LONG).show() }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#2B2B2B")) }
        webView = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#2B2B2B"))
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        root.addView(webView); setContentView(root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(b.left, b.top, b.right, b.bottom); insets
        }
        webView.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true      // IndexedDB / localStorage keep the student's projects
            allowFileAccess = false; allowContentAccess = false; setSupportZoom(false)
        }
        val loader = WebViewAssetLoader.Builder().addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val r = loader.shouldInterceptRequest(request.url) ?: return null
                val path = request.url.path ?: ""
                val mime = when {
                    path.endsWith(".wasm") -> "application/wasm"
                    path.endsWith(".js") || path.endsWith(".mjs") -> "text/javascript"
                    path.endsWith(".json") || path.endsWith(".webmanifest") -> "application/json"
                    path.endsWith(".html") -> "text/html"
                    path.endsWith(".css") -> "text/css"
                    path.endsWith(".svg") -> "image/svg+xml"
                    path.endsWith(".png") -> "image/png"
                    path.endsWith(".py") -> "text/plain"
                    path.endsWith(".zip") || path.endsWith(".whl") -> "application/zip"
                    else -> r.mimeType
                }
                val headers = HashMap<String, String>().apply {
                    put("Cross-Origin-Opener-Policy", "same-origin"); put("Cross-Origin-Embedder-Policy", "require-corp")
                    put("Cross-Origin-Resource-Policy", "same-origin"); put("Access-Control-Allow-Origin", "https://${WebViewAssetLoader.DEFAULT_DOMAIN}")
                }
                return if (r.data == null) r else WebResourceResponse(mime, if (mime.startsWith("text") || mime.endsWith("javascript")) "utf-8" else null, 200, "OK", headers, r.data)
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest) = request.url.host != WebViewAssetLoader.DEFAULT_DOMAIN
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                chooserCallback?.onReceiveValue(null); chooserCallback = cb
                pickFiles.launch(arrayOf("*/*")); return true
            }
        }
        webView.addJavascriptInterface(Bridge(), "AndroidBridge")
        webView.loadUrl("https://${WebViewAssetLoader.DEFAULT_DOMAIN}/assets/index.html")
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { webView.evaluateJavascript("window.BSP_BACK ? window.BSP_BACK() : false") { if (it != "true") finish() } }
        })
    }

    override fun onPause() { super.onPause(); webView.evaluateJavascript("window.dispatchEvent(new Event('beforeunload'))", null) }
    override fun onDestroy() { webView.destroy(); super.onDestroy() }

    /** The only native capability exposed to the page: "save these bytes to a file the student chooses". */
    inner class Bridge {
        @JavascriptInterface
        fun exportFile(name: String, base64: String, mime: String) {
            val safe = name.replace(Regex("[^A-Za-z0-9._ -]"), "_").take(80)
            pendingBytes = Base64.decode(base64, Base64.DEFAULT); pendingName = safe
            runOnUiThread { saveFile.launch(safe) }
        }
    }
}
