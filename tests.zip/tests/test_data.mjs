import 'fake-indexeddb/auto';
import * as fflate from 'fflate';
import * as S from '../www/js/storage.js';
import * as Z from '../www/js/zipio.js';
import { STR, t, setLang } from '../www/js/i18n.js';
import { test, eq, ok, has, done } from './lib.mjs';

await test('16. projects + files persist; folders; rename moves children', async () => {
  await S.createProject('P1'); await S.createEntry('P1', 'main.py', 'file', 'print(1)'); await S.createEntry('P1', 'lib/util.py', 'file', 'x=1');
  const l = await S.listEntries('P1'); eq(l.map(e => e.path), ['lib', 'lib/util.py', 'main.py']); eq(l[0].type, 'dir');
  await S.renameEntry('P1', 'lib', 'tools'); eq((await S.listEntries('P1')).map(e => e.path), ['main.py', 'tools', 'tools/util.py']);
  S.resetForTests(); // simulate app restart: data must still be there
  eq((await S.getEntry('P1', 'main.py')).content, 'print(1)');
});
await test('never overwrite: createEntry/renameEntry refuse existing, uniquePath suggests a free name', async () => {
  let e1 = ''; try { await S.createEntry('P1', 'main.py', 'file', 'X'); } catch (e) { e1 = e.message; } eq(e1, 'exists');
  let e2 = ''; try { await S.renameEntry('P1', 'tools/util.py', 'main.py'); } catch (e) { e2 = e.message; } eq(e2, 'exists');
  eq((await S.getEntry('P1', 'main.py')).content, 'print(1)'); eq(await S.uniquePath('P1', 'main.py'), 'main (2).py');
});
await test('8/16. draft recovery: draft kept until commit, currentText prefers draft', async () => {
  await S.saveDraft('P1', 'main.py', 'print(2)  # typed, not committed'); S.resetForTests();
  const e = await S.getEntry('P1', 'main.py'); eq(e.content, 'print(1)'); eq(S.currentText(e), 'print(2)  # typed, not committed');
  await S.commit('P1', 'main.py', 'print(3)'); const c = await S.getEntry('P1', 'main.py'); eq(c.content, 'print(3)'); eq(S.currentText(c), 'print(3)');
});
await test('delete folder removes children only after explicit call; project delete; settings', async () => {
  eq(await S.deleteEntry('P1', 'tools'), 2); eq((await S.listEntries('P1')).length, 1);
  await S.setKV('settings', { lang: 'ar' }); eq((await S.getKV('settings')).lang, 'ar'); eq(await S.getKV('none', 7), 7);
  await S.createProject('P2'); await S.deleteProject('P2'); eq((await S.listProjects()).map(p => p.name), ['P1']); eq(await S.uniqueProjectName('P1'), 'P1 (2)');
});

Z.setZipLib(fflate);
await test('ZIP export/import round trip (Arabic text included)', async () => {
  const src = { 'main.py': 'print("مرحبا")\n', 'sub/data.csv': 'a,b\n1,2\n' };
  const r = Z.readZip(Z.buildZip(src)); eq(r.files, src); eq(r.skipped, []);
});
await test('ZIP validation: zip-slip, absolute paths, binary, oversize, bombs, corrupt', async () => {
  const mk = (o) => fflate.zipSync(o);
  const e = fflate.strToU8;
  const r = Z.readZip(mk({ '../evil.py': e('x'), '/abs.py': e('x'), 'ok.py': e('print(1)'), 'img.png': e('x'), 'C:\\win.py': e('x'), 'bad.txt': new Uint8Array([0xff, 0xfe, 0xfa]) }));
  eq(Object.keys(r.files), ['ok.py']); eq(r.skipped.length, 5);
  const big = new Uint8Array(Z.LIMITS.perFile + 1).fill(97); eq(Object.keys(Z.readZip(mk({ 'big.py': big })).files), []);
  const many = {}; for (let i = 0; i < Z.LIMITS.entries + 1; i++) many[`f${i}.py`] = e('1'); let m = ''; try { Z.readZip(mk(many)); } catch (x) { m = x.message; } eq(m, 'zip-too-big');
  const half = new Uint8Array(1.5 * 1024 * 1024).fill(97), bomb = {}; for (let i = 0; i < 15; i++) bomb[`b${i}.py`] = half; m = ''; try { Z.readZip(mk(bomb)); } catch (x) { m = x.message; } eq(m, 'zip-too-big');
  m = ''; try { Z.readZip(new Uint8Array([1, 2, 3, 4])); } catch (x) { m = x.message; } eq(m, 'zip-invalid');
});
await test('i18n: Arabic/English/French define exactly the same keys, placeholders match', async () => {
  const en = Object.keys(STR.en).sort();
  for (const l of ['ar', 'fr']) { eq(Object.keys(STR[l]).sort(), en, l + ' keys'); for (const k of en) eq((STR[l][k].match(/\{\w+\}/g) || []).sort(), (STR.en[k].match(/\{\w+\}/g) || []).sort(), `${l}.${k} placeholders`); }
  setLang('ar'); has(t('confirmDelete', { name: 'a.py' }), 'a.py'); setLang('en');
});
done();
