plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "dz.univbouira.pythonstudio"
    compileSdk = 35
    defaultConfig {
        applicationId = "dz.univbouira.pythonstudio"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "2.0.0"
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    // The web app (index.html, js/, pyodide/ ...) is the SAME www/ folder used by the browser/PWA version.
    sourceSets["main"].assets.srcDirs("../../www")
    androidResources {
        noCompress += listOf("wasm", "whl", "zip", "json", "js", "py", "so")
        ignoreAssetsPattern = "!sw.js:!precache.json:!.DS_Store"       // service worker is not used inside the wrapper
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.12.1")
}
