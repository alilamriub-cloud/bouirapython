import { JSDOM } from 'jsdom';
import { test, eq, ok, has, done } from './lib.mjs';
const dom = new JSDOM('<!doctype html><body><div id="p"></div></body>', { pretendToBeVisual: true });
for (const k of ['window', 'document', 'navigator', 'MutationObserver', 'getComputedStyle', 'Node', 'KeyboardEvent', 'HTMLElement', 'requestAnimationFrame', 'cancelAnimationFrame', 'DOMParser', 'Range']) {
  try { Object.defineProperty(globalThis, k, { value: dom.window[k] ?? (k === 'getComputedStyle' ? dom.window.getComputedStyle.bind(dom.window) : undefined), configurable: true, writable: true }); } catch (e) {}
}
dom.window.document.createRange = () => ({ setStart() {}, setEnd() {}, getClientRects: () => [], getBoundingClientRect: () => ({ left: 0, right: 0, top: 0, bottom: 0 }), commonAncestorContainer: dom.window.document.body });
const { createEditorHost, makeCompletionSource, parseImports } = await import('../editor/src/lib.js');
const { EditorView, runScopeHandlers } = await import('../editor/node_modules/@codemirror/view/dist/index.js');
const { CompletionContext, startCompletion, currentCompletions } = await import('../editor/node_modules/@codemirror/autocomplete/dist/index.js');
const { EditorState } = await import('../editor/node_modules/@codemirror/state/dist/index.js');

const host = createEditorHost(dom.window.document.getElementById('p'), { syntaxCheck: async () => [] });
const view = host.view;
const setDoc = (text, pos = text.length) => { view.setState(host.newState(text)); view.dispatch({ selection: { anchor: pos } }); };
const press = (key) => runScopeHandlers(view, new dom.window.KeyboardEvent('keydown', { key, bubbles: true, cancelable: true }), 'editor');
function type(text) {
  for (const ch of text) {
    if (ch === '\n') { press('Enter'); continue; }
    const { from, to } = view.state.selection.main; let handled = false;
    for (const h of view.state.facet(EditorView.inputHandler)) if (h(view, from, to, ch, () => view.state.update({ changes: { from, to, insert: ch } }))) { handled = true; break; }
    if (!handled) view.dispatch({ changes: { from, to, insert: ch }, selection: { anchor: from + ch.length }, userEvent: 'input.type' });
  }
}
const text = () => view.state.doc.toString();

await test('6. automatic indentation after if/elif/else/for/while/def/class/try/except/finally/with', async () => {
  for (const head of ['if x > 1:', 'elif y:', 'else:', 'for i in range(3):', 'while True:', 'def f(a, b):', 'class A:', 'try:', 'except ValueError:', 'finally:', 'with open("f") as fh:']) {
    setDoc(''); type(head + '\n'); eq(text(), head + '\n    ', head);
  }
  setDoc(''); type('if x:  # comment\n'); eq(text(), 'if x:  # comment\n    ');
});
await test('indentation is kept, nested blocks stack, return/pass/break dedent one level', async () => {
  setDoc(''); type('def f(n):\n'); type('if n:\n'); type('return 1\n'); eq(text(), 'def f(n):\n    if n:\n        return 1\n    ');
  setDoc(''); type('for i in x:\n'); type('print(i)\n'); eq(text(), 'for i in x:\n    print(i)\n    ');
  setDoc(''); type('x = (1 +\n'); ok(text().startsWith('x = (1 +\n'));
});
await test('dedent when typing else:/elif:/except: after a body line', async () => {
  setDoc(''); type('if a:\n'); type('x = 1\n'); type('else:'); eq(text(), 'if a:\n    x = 1\nelse:');
  setDoc(''); type('try:\n'); type('pass\n'); type('except ValueError:'); has(text(), '\nexcept ValueError:');
});
await test('automatic bracket and quote completion + type-over', async () => {
  setDoc(''); type('('); eq(text(), '()'); type(')'); eq(text(), '()'); eq(view.state.selection.main.head, 2);
  setDoc(''); type('print("hi'); eq(text(), 'print("hi")'); setDoc(''); type('[{'); eq(text(), '[{}]'); setDoc(''); type("'"); eq(text(), "''");
});
await test('Tab indents, undo/redo work', async () => {
  setDoc('x = 1', 0); press('Tab'); eq(text(), '    x = 1'); host.undo(); eq(text(), 'x = 1'); host.redo(); eq(text(), '    x = 1');
});
await test('7. autocomplete from the first typed character: keywords, built-ins, own identifiers, library members', async () => {
  const run = async (doc, explicit = false, src = makeCompletionSource({})) => { const st = EditorState.create({ doc }); const r = await src(new CompletionContext(st, doc.length, explicit)); return r ? r.options.map(o => o.label) : []; };
  const chk=(c,m)=>{ if(!c) throw new Error('autocomplete: '+m); };
  chk((await run('w')).includes('while'),'w->while'); chk((await run('p')).includes('print'),'p->print'); chk((await run('f')).includes('for'),'f->for');
  chk((await run('total_price = 3\nto')).includes('total_price'),'total_price = 3\nto'+' -> total_price');
  chk((await run('import numpy as np\nnp.li')).includes('linspace'),'import numpy as np\nnp.li'+' -> linspace'); 
  chk((await run('import matplotlib.pyplot as plt\nplt.s')).includes('scatter'),'import matplotlib.pyplot as plt\nplt.s'+' -> scatter'); chk((await run('from scipy import stats\nstats.nor')).includes('norm'),'from scipy import stats\nstats.nor'+' -> norm');
  chk((await run('import math\nmath.sq')).includes('sqrt'),'import math\nmath.sq'+' -> sqrt'); chk((await run('import statistics\nstatistics.me')).includes('median'),'import statistics\nstatistics.me'+' -> median');
  chk((await run('x = [1]\nx.ap')).includes('append'),'x = [1]\nx.ap'+' -> append');
  eq((await run('')).length, 0);
  const live = makeCompletionSource({ introspect: async (spec) => spec.var === 'df' ? [['groupby', 'function'], ['shape', 'variable']] : spec.module === 'numpy' ? [['linalg', 'module'], ['linspace', 'function']] : null });
  eq(await run('df.', false, live), ['groupby', 'shape']); ok((await run('import numpy as np\nnp.', false, live)).includes('linalg'));
  eq(parseImports('from scipy import stats as st\nimport numpy as np').alias.st, 'scipy.stats');
});
await test('Enter accepts the highlighted suggestion (does not insert a newline)', async () => {
  setDoc('pri'); startCompletion(view); await new Promise(r => setTimeout(r, 400));
  ok(currentCompletions(view.state).length > 0, 'popup open'); press('Enter'); await new Promise(r => setTimeout(r, 50));
  ok(!text().includes('\n'), 'no newline: ' + JSON.stringify(text())); has(text(), 'print');
});
await test('multiple tabs keep separate documents and undo history', async () => {
  const a = host.newState('A = 1'), b = host.newState('B = 2'); host.setState(a); view.dispatch({ changes: { from: 5, insert: '0' } }); const a2 = host.getState();
  host.setState(b); eq(text(), 'B = 2'); ok(!host.canUndo()); host.setState(a2); eq(text(), 'A = 10'); ok(host.canUndo());
});
done();
