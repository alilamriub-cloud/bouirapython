import fs from 'node:fs';
import { STR } from '../www/js/i18n.js';
import { test, eq, ok, done } from './lib.mjs';
const read = (p) => fs.readFileSync(new URL('../www/' + p, import.meta.url), 'utf8');
await test('every t("key") and data-i18n key used by the app exists in en, fr and ar', async () => {
  const used = new Set();
  for (const f of ['js/main.js']) for (const m of read(f).matchAll(/\bt\('(\w+)'/g)) used.add(m[1]);
  for (const m of read('index.html').matchAll(/data-i18n(?:-title|-ph)?="(\w+)"/g)) used.add(m[1]);
  for (const k of Object.keys(STR.en).filter(k => k.startsWith('st_'))) used.add(k);
  ok(used.size > 60, 'found ' + used.size);
  for (const l of ['en', 'fr', 'ar']) eq([...used].filter(k => !(k in STR[l])), [], l + ' missing');
});
await test('Arabic strings are really Arabic (not copies of English)', async () => {
  const same = Object.keys(STR.en).filter(k => STR.ar[k] === STR.en[k] && /[a-z]{4,}/i.test(STR.en[k]) && !['appName', 'savePNG', 'saveSVG'].includes(k)); eq(same, []);
});
done();
