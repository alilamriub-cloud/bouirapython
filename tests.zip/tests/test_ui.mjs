// Drives the REAL index.html + main.js (jsdom) with the REAL worker.js/Pyodide (worker_threads). Layout/CSS is not covered here.
import 'fake-indexeddb/auto';
import fs from 'node:fs';
import { JSDOM } from 'jsdom';
import { test, eq, ok, has, done } from './lib.mjs';
import { BASE, nodeWorker } from './helpers/harness.mjs';

const html = fs.readFileSync(new URL('../www/index.html', import.meta.url), 'utf8').replace(/<script[\s\S]*?<\/script>/g, '');
const dom = new JSDOM(html, { pretendToBeVisual: true, url: 'http://localhost/' });
const w = dom.window; let phone = false;
w.matchMedia = (q) => ({ matches: /max-width: 799px/.test(q) ? phone : false, addEventListener() {}, removeEventListener() {} });
w.Element.prototype.scrollIntoView = () => {}; w.HTMLElement.prototype.setPointerCapture = () => {};
for (const k of ['window', 'document', 'HTMLElement', 'KeyboardEvent', 'Event', 'MutationObserver', 'Node', 'DOMParser', 'Range', 'requestAnimationFrame', 'cancelAnimationFrame', 'sessionStorage', 'localStorage'])
  Object.defineProperty(globalThis, k, { value: w[k] ?? (k === 'window' ? w : undefined), configurable: true, writable: true });
globalThis.window = w; globalThis.getComputedStyle = w.getComputedStyle.bind(w);
w.document.createRange = () => ({ setStart() {}, setEnd() {}, getClientRects: () => [], getBoundingClientRect: () => ({ left: 0, right: 0, top: 0, bottom: 0 }), commonAncestorContainer: w.document.body });
const downloads = []; const realCreate = w.document.createElement.bind(w.document);
w.URL.createObjectURL = (b) => { downloads.push(b); return 'blob:x'; }; w.URL.revokeObjectURL = () => {}; globalThis.URL.createObjectURL = w.URL.createObjectURL;
w.HTMLAnchorElement.prototype.click = function () { downloads.push({ download: this.download }); };
const realFetch = globalThis.fetch; globalThis.fetch = (u, o) => (typeof u === 'string' && u.startsWith('/')) ? Promise.resolve({ json: async () => JSON.parse(fs.readFileSync(u, 'utf8')), text: async () => fs.readFileSync(u, 'utf8') }) : realFetch(u, o);

const lib = await import('../editor/src/lib.js'); w.BSPLib = lib;
w.__BSP_TEST__ = { base: BASE, createWorker: nodeWorker, isolated: true };
await import('../www/js/main.js');
const A = () => w.BSP_APP, $ = (s) => w.document.querySelector(s), $$ = (s) => [...w.document.querySelectorAll(s)];
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const until = async (fn, ms = 60000, what = 'condition') => { const t0 = Date.now(); while (!(await fn())) { if (Date.now() - t0 > ms) throw new Error('timeout waiting for ' + what + '; out=' + JSON.stringify($('#out').textContent.slice(-300))); await sleep(25); } };
const click = (el) => el.dispatchEvent(new w.MouseEvent('click', { bubbles: true, cancelable: true }));
const submit = (form) => form.dispatchEvent(new w.Event('submit', { bubbles: true, cancelable: true }));
const setCode = (code) => { const ed = A().editor; ed.replaceAll(code); };
const answer = async (text) => { await until(() => !$('#inputRow').hidden, 30000, 'input row'); $('#stdin').value = text; submit($('#inputRow')); };
const state = () => $('#stRuntime').className;
const IDLE = ['done', 'error', 'stopped', 'ready'];
const startRun = async () => { const n = A().S.runs || 0; click($('#btnRun')); await until(() => (A().S.runs || 0) > n, 30000, 'run start'); };
const idle = async () => { await until(() => IDLE.includes(state()), 90000, 'program end'); await sleep(120); };
const runIdle = async () => { await startRun(); await idle(); };

await until(() => $('body').classList.contains('ready') && state() === 'ready', 90000, 'Python ready');

await test('boot: project, main.py tab, toolbar, Python ready indicator', async () => {
  eq(A().S.project, 'My First Project'); eq(A().S.tabs.map(x => x.path), ['main.py']); has($('#stFile').textContent, 'main.py'); eq(state(), 'ready'); ok($('#btnRun').disabled === false); ok($('#btnStop').disabled === true);
  has(A().editor.getValue(), 'input("What is your name?'); has($('#stPy').textContent, 'Python 3.12'); has($('#stPy').textContent, 'live');
});
await test('1+2. Run the 3-input program from the spec, answering inside the console (no popups)', async () => {
  setCode('name = input("Enter your name: ")\nage = int(input("Enter your age: "))\nsalary = float(input("Enter your salary: "))\n\nprint("Name:", name)\nprint("Age:", age)\nprint("Salary:", salary)\n');
  await startRun(); await until(() => state() === 'waiting', 30000, 'waiting'); has($('#out').textContent, 'Enter your name: '); ok(!$('#inputRow').hidden);
  const runs = A().S.runs; click($('#btnRun')); await sleep(100); eq(A().S.runs, runs, 'duplicate click ignored');
  $('#stdin').value = 'Amina'; submit($('#inputRow')); await answer('20'); await answer('3500.5');
  await idle(); eq(state(), 'done'); const o = $('#out').textContent;
  has(o, 'Enter your name: Amina\n'); has(o, 'Name: Amina\nAge: 20\nSalary: 3500.5\n'); eq(o.split('Enter your name:').length, 2, 'ran once'); ok($('#inputRow').hidden);
});
await test('conversion error shows traceback; status shows error; run again works', async () => {
  setCode('x = int(input("n: "))\nprint(x)\n'); await startRun(); await answer('abc'); await idle(); eq(state(), 'error');
  has($('#out').textContent, 'ValueError'); has($('#out').textContent, 'Traceback'); setCode('print("ok again")'); await runIdle(); eq(state(), 'done'); has($('#out').textContent, 'ok again');
});
await test('15. Stop a running infinite loop from the toolbar, UI stays responsive, then recover', async () => {
  setCode('while True:\n    pass\n'); await startRun(); await until(() => state() === 'running', 30000); ok($('#btnStop').disabled === false); ok($('#btnRun').disabled === true);
  await sleep(800); click($('#btnStop')); await until(() => state() === 'stopped', 15000, 'stopped'); has($('#out').textContent, 'KeyboardInterrupt');
  setCode('print("recovered")'); await runIdle(); eq(state(), 'done'); has($('#out').textContent, 'recovered');
});
await test('12. matplotlib figure appears in the Plots tab with PNG/SVG save buttons', async () => {
  setCode('import numpy as np\nimport matplotlib.pyplot as plt\nx = np.linspace(-4, 4, 500)\ny = np.exp(-x**2 / 2) / np.sqrt(2*np.pi)\nplt.plot(x, y)\nplt.title("Standard Normal Distribution")\nplt.show()\n');
  await runIdle(); eq(state(), 'done'); ok(!$('#plots').hidden, 'plots tab auto-selected'); eq($$('#plots .fig').length, 1); ok($('#plots img').src.startsWith('data:image/png;base64,'));
  eq($('#plotCount').textContent, '1'); const n = downloads.length; click($('#plots [data-f=svg]')); click($('#plots [data-f=png]')); eq(downloads.length, n + 4 /* blob+anchor each */);
  ok(downloads.some(d => d.download === 'figure_1.svg') && downloads.some(d => d.download === 'figure_1.png'));
});
await test('new file dialog, tabs, file tree; invalid and duplicate names are refused', async () => {
  A().newFile(); await until(() => !$('#modal').hidden); let f = $('#mBody form'); f.querySelector('input').value = 'lesson1'; submit(f);
  await until(() => A().S.tabs.some(t => t.path === 'lesson1.py')); eq(A().S.active, 'lesson1.py'); ok($$('#tree .tr').some(r => r.dataset.path === 'lesson1.py'));
  A().newFile(); await until(() => !$('#modal').hidden); f = $('#mBody form'); f.querySelector('input').value = '../evil'; submit(f); await until(() => $('#modal').hidden); await sleep(150); has($('#toast').textContent, 'Invalid');
  A().newFile(); await until(() => !$('#modal').hidden); f = $('#mBody form'); f.querySelector('input').value = 'lesson1.py'; submit(f); await until(() => $('#modal').hidden); await sleep(150); has($('#toast').textContent, 'already exists');
});
await test('8. save and reopen: content persisted in IndexedDB, survives closing the tab', async () => {
  setCode('print("saved text")\n'); click($('#btnSave')); await sleep(100);
  const DB = await import('../www/js/storage.js'); eq((await DB.getEntry('My First Project', 'lesson1.py')).content, 'print("saved text")\n');
  await A().S.tabs.length; const { closeTab } = {}; click($$('#tabs .tab').find(t => t.dataset.path === 'lesson1.py').querySelector('.x')); await until(() => !A().S.tabs.some(t => t.path === 'lesson1.py'));
  await A().openTab('lesson1.py', true); eq(A().editor.getValue(), 'print("saved text")\n');
});
await test('16. unsaved draft is recovered after "restart" (auto-save off)', async () => {
  const DB = await import('../www/js/storage.js'); A().S.settings.autosave = false; setCode('print("draft only")\n'); await sleep(1000);
  const e = await DB.getEntry('My First Project', 'lesson1.py'); eq(e.content, 'print("saved text")\n'); eq(e.draft, 'print("draft only")\n');
  await A().switchProject('My First Project'); const tb = A().S.tabs.find(t => t.path === 'lesson1.py'); ok(tb.dirty); await A().openTab('lesson1.py', true); eq(A().editor.getValue(), 'print("draft only")\n');
  A().S.settings.autosave = true; click($('#btnSave')); await sleep(100); eq((await DB.getEntry('My First Project', 'lesson1.py')).content, 'print("draft only")\n');
});
await test('examples library: opens a chapter example as a new file without overwriting', async () => {
  await A().showExamples(); const items = $$('#mBody .li'); ok(items.length >= 38); eq($$('#mBody .chap').length, 21); click(items[0]); await until(() => A().S.tabs.some(t => t.path === 'examples/ch01_hello.py')); await sleep(100);
  has(A().editor.getValue(), 'Hello, World!'); await A().showExamples(); click($$('#mBody .li')[0]); await until(() => A().S.tabs.some(t => t.path === 'examples/ch01_hello (2).py')); await sleep(150); has($('#toast').textContent, 'kept');
});
await test('project files: import helper module + file written by the program appears in the tree', async () => {
  const DB = await import('../www/js/storage.js'); await DB.createEntry('My First Project', 'helper.py', 'file', 'def double(x):\n    return 2 * x\n'); await A().switchProject('My First Project');
  A().S.tabs.forEach(t => (t.dirty = false)); await A().openTab('main.py', true); setCode('import helper\nprint(helper.double(21))\nopen("result.txt", "w").write("42")\n'); await runIdle(); eq(state(), 'done'); has($('#out').textContent, '42'); await until(() => $$('#tree .tr').some(r => r.dataset.path === 'result.txt'), 5000, 'result.txt in tree');
});
await test('library panel lists bundled libraries with versions', async () => {
  await A().showLibs(); await until(() => /numpy/.test($('#mBody').textContent)); const txt = $('#mBody').textContent; for (const n of ['numpy', 'pandas', 'scipy', 'matplotlib', 'sympy', 'statsmodels', 'scikit-learn', 'seaborn']) has(txt, n); has(txt, 'Bundled offline'); ok(/numpy\s+\d+\.\d+/.test(txt), 'version shown'); $('#mClose').click();
});
await test('ZIP export then import creates a NEW project (never overwrites)', async () => {
  downloads.length = 0; await A().exportZip(); const blob = downloads.find(d => d.size !== undefined); ok(blob && blob.size > 100);
  const file = new File([await blob.arrayBuffer()], 'backup.zip'); await A().importZipFile(file); eq(A().S.project, 'backup'); ok(A().S.entries.some(e => e.path === 'helper.py')); const DB = await import('../www/js/storage.js'); eq((await DB.listProjects()).length, 2);
  await A().switchProject('My First Project');
});
await test('Arabic UI is RTL while editor and console stay LTR; labels translated', async () => {
  A().S.settings.lang = 'ar'; const { setLang, applyI18n } = await import('../www/js/i18n.js'); setLang('ar'); applyI18n();
  eq(w.document.documentElement.dir, 'rtl'); eq($('#editor').getAttribute('dir'), 'ltr'); eq($('#consoleWrap').getAttribute('dir'), 'ltr'); eq($('#btnRun').textContent.trim(), 'تشغيل'); eq(A().editor.view.dom.getAttribute('dir'), 'ltr');
  setLang('fr'); applyI18n(); eq($('#btnRun').textContent.trim(), 'Exécuter'); eq(w.document.documentElement.dir, 'ltr'); setLang('en'); applyI18n();
});
await test('14. phone layout logic: Run switches to the Output view, keys row present with required symbols', async () => {
  phone = true; A().S.settings.lang = 'en'; click($$('#bottomNav button').find(b => b.dataset.view === 'editor')); eq(w.document.body.dataset.view, 'editor');
  setCode('print("phone")'); await runIdle(); eq(w.document.body.dataset.view, 'output');
  const keys = $$('#keys button').map(b => b.textContent); for (const k of [':', '()', '[]', '{}', '=', '==', '+', '-', '_', 'Tab']) ok(keys.includes(k), 'key ' + k);
  const before = A().editor.getValue(); click($$('#bottomNav button').find(b => b.dataset.view === 'editor')); A().editor.view.dispatch({ selection: { anchor: A().editor.getValue().length } });
  $$('#keys button').find(b => b.textContent === '()').dispatchEvent(new w.Event('pointerdown', { bubbles: true, cancelable: true })); eq(A().editor.getValue(), before + '()'); phone = false;
});
A().rt.w.terminate(); done();
