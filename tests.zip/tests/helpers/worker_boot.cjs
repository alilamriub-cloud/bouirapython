// Runs the REAL www/js/worker.js inside a Node worker_thread by emulating the few Web Worker globals it needs.
const { parentPort } = require('worker_threads');
const fs = require('fs'), path = require('path');
globalThis.self = globalThis;
self.postMessage = (m) => parentPort.postMessage(m);
globalThis.importScripts = (u) => { globalThis.loadPyodide = require(u).loadPyodide; };
const realFetch = globalThis.fetch;
globalThis.fetch = (u, o) => (typeof u === 'string' && u.startsWith('/')) ? Promise.resolve({ text: async () => fs.readFileSync(u, 'utf8') }) : realFetch(u, o);
require(path.resolve(__dirname, '../../www/js/worker.js'));
parentPort.on('message', (d) => self.onmessage({ data: d }));
