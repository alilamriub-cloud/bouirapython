#!/bin/sh
# Re-bundles CodeMirror + fflate into www/js/vendor.bundle.js (Node 18+). The bundle is already included in the ZIP.
cd "$(dirname "$0")/../editor" && npm install --no-audit --no-fund && npm run build
