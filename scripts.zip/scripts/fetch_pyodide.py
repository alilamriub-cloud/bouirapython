#!/usr/bin/env python3
"""
Offline preparation: downloads the official Pyodide release ONCE (needs internet on the developer/teacher PC),
keeps only the packages Bouira Python Studio offers, and writes them to www/pyodide/.

  python3 scripts/fetch_pyodide.py                 # default bundle
  python3 scripts/fetch_pyodide.py --add networkx  # add another package of the Pyodide distribution (+dependencies)
  python3 scripts/fetch_pyodide.py --all           # keep EVERYTHING in the distribution (~400 MB)
"""
import argparse, hashlib, json, shutil, sys, tarfile, urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "www/pyodide"
CACHE = ROOT / "scripts/cache"

WANTED = ["numpy", "pandas", "matplotlib", "scipy", "sympy", "statsmodels", "scikit-learn", "micropip",
          "patsy", "mpmath", "pillow", "python-dateutil", "pytz", "six", "packaging", "pyparsing", "regex"]
# Pure-Python wheels that are not part of the Pyodide distribution: fetched from PyPI and registered in the lock file.
EXTRA_WHEELS = {
    "seaborn": {"version": "0.13.2", "depends": ["numpy", "pandas", "matplotlib"]},
    "pycodestyle": {"version": "2.12.1", "depends": []},
    "autopep8": {"version": "2.3.1", "depends": ["pycodestyle"]},   # used by the "Format code" button
}
CORE = ["pyodide.js", "pyodide.asm.js", "pyodide.asm.wasm", "python_stdlib.zip", "pyodide-lock.json", "package.json"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--version", default="0.27.7")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--add", action="append", default=[], help="extra Pyodide package name (repeatable)")
    a = ap.parse_args()

    CACHE.mkdir(parents=True, exist_ok=True)
    tarball = CACHE / f"pyodide-{a.version}.tar.bz2"
    if not tarball.exists():
        url = f"https://github.com/pyodide/pyodide/releases/download/{a.version}/pyodide-{a.version}.tar.bz2"
        print("Downloading", url, "(this is the only online step)")
        urllib.request.urlretrieve(url, tarball)
    src = CACHE / f"extract-{a.version}"
    if not src.exists():
        print("Extracting ...")
        with tarfile.open(tarball) as t:
            t.extractall(src)
    base = next(p for p in src.rglob("pyodide-lock.json")).parent

    lock = json.loads((base / "pyodide-lock.json").read_text())
    pk = lock["packages"]
    norm = lambda n: n.lower().replace("_", "-")
    byname = {norm(k): k for k in pk}

    keep, todo = set(), []
    for w in (list(pk.keys()) if a.all else WANTED + a.add):
        key = byname.get(norm(w))
        if key is None:
            print(f"  ! '{w}' is NOT in this Pyodide release - skipped")
            continue
        todo.append(key)
    while todo:
        k = todo.pop()
        if k in keep:
            continue
        keep.add(k)
        for d in pk[k].get("depends", []):
            todo.append(byname[norm(d)])

    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)
    for f in CORE:
        if (base / f).exists():
            shutil.copy2(base / f, OUT / f)
    total = 0
    for k in sorted(keep):
        f = base / pk[k]["file_name"]
        shutil.copy2(f, OUT / f.name)
        total += f.stat().st_size
    lock["packages"] = {k: pk[k] for k in keep}
    for name, meta in EXTRA_WHEELS.items():
        try:
            info = json.load(urllib.request.urlopen(f"https://pypi.org/pypi/{name}/{meta['version']}/json"))
            whl = next(u for u in info["urls"] if u["filename"].endswith("-none-any.whl"))
            data = urllib.request.urlopen(whl["url"]).read()
            (OUT / whl["filename"]).write_bytes(data)
            lock["packages"][name] = {
                "name": name, "version": meta["version"], "file_name": whl["filename"], "install_dir": "site",
                "sha256": hashlib.sha256(data).hexdigest(), "package_type": "package",
                "imports": [name], "depends": meta["depends"], "unvendored_tests": False, "shared_library": False}
            keep.add(name)
            print(f"  + {name} {meta['version']} (pure-Python wheel from PyPI)")
        except Exception as e:
            print(f"  ! could not add {name}: {e}")
    (OUT / "pyodide-lock.json").write_text(json.dumps(lock))
    print(f"Kept {len(keep)} packages ({total/1e6:.1f} MB core wheels):")
    print("  " + ", ".join(sorted(keep)))
    print("Pyodide", lock["info"].get("version"), "Python", lock["info"].get("python"), "->", OUT)


if __name__ == "__main__":
    sys.exit(main())
