// Minimal test runner: node tests/x.mjs ; prints PASS/FAIL and exits non-zero on failure.
let pass = 0, fail = 0; const failed = [];
export async function test(name, fn) {
  const t0 = Date.now();
  try { await fn(); pass++; console.log(`PASS  ${name} (${Date.now() - t0} ms)`); }
  catch (e) { fail++; failed.push(name); console.log(`FAIL  ${name}\n      ${String(e.message || e).split('\n').join('\n      ')}`); }
}
export function eq(a, b, msg = '') { if (JSON.stringify(a) !== JSON.stringify(b)) throw new Error(`${msg} expected ${JSON.stringify(b)} got ${JSON.stringify(a)}`); }
export function ok(c, msg = 'assertion failed') { if (!c) throw new Error(msg); }
export function has(s, sub, msg = '') { if (!String(s).includes(sub)) throw new Error(`${msg} expected to contain ${JSON.stringify(sub)} in ${JSON.stringify(String(s).slice(0, 400))}`); }
export function done() { console.log(`\n${pass} passed, ${fail} failed${fail ? ': ' + failed.join(', ') : ''}`); process.exit(fail ? 1 : 0); }
