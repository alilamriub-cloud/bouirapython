// Runs every test file in a separate process and prints a summary. Usage: node tests/run_all.mjs [--fast]
import { spawnSync } from 'node:child_process';
const fast = process.argv.includes('--fast');
const files = ['test_data.mjs', 'test_i18n_usage.mjs', 'test_editor.mjs', 'test_pwa.mjs', ...(fast ? [] : ['test_runtime.mjs', 'test_examples.mjs', 'test_ui.mjs'])];
let bad = 0;
for (const f of files) {
  const r = spawnSync('node', ['tests/' + f], { stdio: 'inherit', timeout: 1800000 });
  if (r.status !== 0) { bad++; console.log(`\n>>> ${f} FAILED\n`); }
}
console.log(bad ? `\n${bad} test file(s) failed` : '\nALL TEST FILES PASSED'); process.exit(bad ? 1 : 0);
