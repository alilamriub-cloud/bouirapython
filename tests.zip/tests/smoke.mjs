import { makeRuntime } from './helpers/harness.mjs';
const { rt, log } = makeRuntime({ live: true, answers: ['Amina', '20', '3500.5'] });
console.time('init'); await rt.start(); console.timeEnd('init'); console.log(rt.info);
const code = `name = input("Enter your name: ")
age = int(input("Enter your age: "))
salary = float(input("Enter your salary: "))
print("Name:", name); print("Age:", age); print("Salary:", salary)`;
const r = await rt.run({ code, filename: 'main.py', files: { 'main.py': code } });
console.log(r, JSON.stringify(log.out), log.err, log.prompts);
process.exit(0);
