#!/usr/bin/env python3
"""
Local web server for Bouira Python Studio (standard library only - no installation needed).
Sends the headers that make the page cross-origin isolated (required for interactive input() in "live" mode)
and the correct MIME type for WebAssembly.

  python serve.py                # http://localhost:8000  (this computer only)
  python serve.py --port 9000
  python serve.py --lan          # also reachable from phones on the same Wi-Fi (see README: http on a LAN has no service worker / SharedArrayBuffer)
"""
import argparse, http.server, mimetypes, os, socket, sys, threading, webbrowser
from pathlib import Path

mimetypes.add_type("application/wasm", ".wasm"); mimetypes.add_type("text/javascript", ".js"); mimetypes.add_type("text/javascript", ".mjs")
mimetypes.add_type("application/manifest+json", ".webmanifest"); mimetypes.add_type("application/zip", ".whl"); mimetypes.add_type("image/svg+xml", ".svg")


class Handler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Cross-Origin-Opener-Policy", "same-origin")
        self.send_header("Cross-Origin-Embedder-Policy", "require-corp")
        self.send_header("Cross-Origin-Resource-Policy", "same-origin")
        self.send_header("Cache-Control", "no-cache")           # always revalidate; the service worker does the offline caching
        self.send_header("X-Content-Type-Options", "nosniff")
        super().end_headers()

    def log_message(self, fmt, *args):
        if os.environ.get("BSP_QUIET") != "1":
            super().log_message(fmt, *args)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--lan", action="store_true", help="listen on all network interfaces")
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--dir", default=str(Path(__file__).resolve().parent.parent / "www"))
    a = ap.parse_args()
    if not (Path(a.dir) / "index.html").exists():
        sys.exit(f"index.html not found in {a.dir}")
    if not (Path(a.dir) / "pyodide" / "pyodide.asm.wasm").exists():
        print("WARNING: www/pyodide is missing. Run:  python scripts/fetch_pyodide.py   (needs internet once)")
    os.chdir(a.dir)
    host = "0.0.0.0" if a.lan else "127.0.0.1"
    srv = http.server.ThreadingHTTPServer((host, a.port), Handler)
    url = f"http://localhost:{a.port}/"
    print(f"Bouira Python Studio is running at {url}   (Ctrl+C to stop)")
    if a.lan:
        try: ip = socket.gethostbyname(socket.gethostname()); print(f"On the same Wi-Fi: http://{ip}:{a.port}/  (compatibility mode: see README)")
        except OSError: pass
    if not a.no_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try: srv.serve_forever()
    except KeyboardInterrupt: print("\nStopped.")


if __name__ == "__main__":
    main()
