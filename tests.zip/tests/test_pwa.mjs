// Offline/PWA checks: real HTTP server + the REAL sw.js executed in a simulated service-worker scope (no browser needed).
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { test, eq, ok, has, done } from './lib.mjs';
const root = path.resolve(new URL('..', import.meta.url).pathname), www = path.join(root, 'www');
const ORIGIN = 'http://127.0.0.1:8766';
const srv = spawn('python3', ['scripts/serve.py', '--port', '8766', '--no-browser'], { cwd: root, env: { ...process.env, BSP_QUIET: '1' }, stdio: 'ignore' });
await new Promise(r => setTimeout(r, 1500));
const list = JSON.parse(fs.readFileSync(path.join(www, 'precache.json'), 'utf8'));

await test('precache.json lists only existing files and covers every runtime file', async () => {
  for (const f of list.files) ok(fs.existsSync(path.join(www, f)), 'missing ' + f);
  for (const must of ['index.html', 'css/app.css', 'js/main.js', 'js/worker.js', 'js/runtime.js', 'js/vendor.bundle.js', 'python/runner.py', 'pyodide/pyodide.asm.wasm', 'pyodide/python_stdlib.zip', 'pyodide/pyodide-lock.json', 'manifest.webmanifest', 'sw.js']) ok(list.files.includes(must), must);
  ok(list.files.some(f => /numpy.*\.whl$/.test(f)) && list.files.some(f => /pandas.*\.whl$/.test(f)) && list.files.some(f => /scipy.*\.whl$/.test(f)));
  const lock = JSON.parse(fs.readFileSync(path.join(www, 'pyodide/pyodide-lock.json'), 'utf8')).packages; for (const p of Object.values(lock)) ok(list.files.includes('pyodide/' + p.file_name), 'wheel missing: ' + p.file_name);
});
await test('no CDN / remote dependencies in application sources', async () => {
  for (const f of ['index.html', 'css/app.css', 'js/main.js', 'js/runtime.js', 'js/worker.js', 'js/storage.js', 'js/i18n.js', 'js/zipio.js', 'js/examples.js', 'sw.js', 'python/runner.py', 'manifest.webmanifest']) {
    const txt = fs.readFileSync(path.join(www, f), 'utf8').replace(/\/\*[\s\S]*?\*\/|\/\/.*$/gm, '');
    const hits = (txt.match(/https?:\/\/[^\s'"`)]+/g) || []).filter(u => !/localhost|127\.0\.0\.1|w3\.org|appassets/.test(u)); eq(hits, [], f);
  }
  ok(!/(cdn|unpkg|jsdelivr|googleapis)/i.test(fs.readFileSync(path.join(www, 'index.html'), 'utf8')));
});
await test('server sends COOP/COEP + correct MIME for wasm/js/manifest', async () => {
  const w = await fetch(ORIGIN + '/pyodide/pyodide.asm.wasm'); eq(w.headers.get('content-type'), 'application/wasm'); eq(w.headers.get('cross-origin-opener-policy'), 'same-origin'); eq(w.headers.get('cross-origin-embedder-policy'), 'require-corp');
  has((await fetch(ORIGIN + '/js/main.js')).headers.get('content-type'), 'javascript'); has((await fetch(ORIGIN + '/manifest.webmanifest')).headers.get('content-type'), 'manifest');
});

function makeCaches() {
  const store = new Map(); const keyOf = (r, o = {}) => { const u = new URL(typeof r === 'string' ? r : (r instanceof URL ? r.href : r.url)); if (o.ignoreSearch) u.search = ''; return u.href; };
  const mkCache = (m) => ({
    async match(r, o) { const e = m.get(keyOf(r, o)); return e ? new Response(e.buf.slice(0), { status: e.status, headers: e.headers }) : undefined; },
    async put(r, res) { m.set(keyOf(r), { buf: await res.arrayBuffer(), status: res.status, headers: [...res.headers] }); },
    async keys() { return [...m.keys()].map(u => new Request(u)); },
  });
  return { async open(n) { if (!store.has(n)) store.set(n, new Map()); return mkCache(store.get(n)); }, async keys() { return [...store.keys()]; }, async delete(n) { return store.delete(n); },
    async match(r, o) { for (const m of store.values()) { const e = await mkCache(m).match(r, o); if (e) return e; } } };
}
function makeSW(online) {
  const handlers = {}, messages = [], caches = makeCaches(); let net = online;
  const self = { location: { origin: ORIGIN }, registration: { scope: ORIGIN + '/' }, skipWaiting() {}, clients: { claim: async () => {}, matchAll: async () => [{ postMessage: (m) => messages.push(m) }] }, addEventListener: (t, f) => (handlers[t] = f) };
  const fetchFn = (r, o) => { if (!net) return Promise.reject(new TypeError('offline')); return fetch(typeof r === 'string' || r instanceof URL ? r : r.url, o); };
  new Function('self', 'caches', 'fetch', 'Response', 'Request', 'Headers', 'URL', fs.readFileSync(path.join(www, 'sw.js'), 'utf8'))(self, caches, fetchFn, Response, Request, Headers, URL);
  const fire = async (req) => { let p = null; handlers.fetch({ request: req, respondWith: (x) => (p = x) }); return p ? await p : null; };
  return { handlers, messages, caches, fire, setOnline: (v) => (net = v) };
}
const getReq = (p, extra = {}) => ({ url: ORIGIN + p, method: 'GET', mode: 'cors', headers: new Headers(), ...extra });

const sw = makeSW(true);
await test('13. service worker precaches the whole app (first run online)', async () => {
  let promise; sw.handlers.message({ data: { type: 'precache' }, waitUntil: (p) => (promise = p) }); await promise;
  const c = await sw.caches.open('bsp-' + list.build); eq((await c.keys()).length, list.files.length); ok(sw.messages.some(m => m.type === 'precache-done')); const last = sw.messages.filter(m => m.type === 'precache-progress').pop(); eq(last.done, last.total);
});
await test('13. OFFLINE: app shell, worker, wasm and wheels are served from the cache with COOP/COEP headers', async () => {
  sw.setOnline(false);
  for (const p of ['/index.html', '/js/worker.js', '/pyodide/pyodide.asm.wasm', '/pyodide/pyodide-lock.json', '/python/runner.py', '/manifest.webmanifest']) {
    const r = await sw.fire(getReq(p)); ok(r && r.status === 200, p); eq(r.headers.get('cross-origin-embedder-policy'), 'require-corp', p); eq(r.headers.get('cross-origin-opener-policy'), 'same-origin', p);
    const orig = fs.readFileSync(path.join(www, p)); eq((await r.arrayBuffer()).byteLength, orig.length, p + ' size');
  }
  const nav = await sw.fire(getReq('/', { mode: 'navigate' })); ok(nav && nav.status === 200); has(await nav.text(), 'Bouira Python Studio');
  const nav2 = await sw.fire(getReq('/index.html?x=1', { mode: 'navigate' })); ok(nav2.status === 200);
  const missing = await sw.fire(getReq('/not-cached.js')); eq(missing.status, 503);
});
await test('SW ignores non-GET and cross-origin requests', async () => {
  eq(await sw.fire(getReq('/x', { method: 'POST' })), null); eq(await sw.fire({ url: 'https://example.com/a.js', method: 'GET', mode: 'cors', headers: new Headers() }), null);
});
await test('manifest + icons valid for installable PWA', async () => {
  const m = JSON.parse(fs.readFileSync(path.join(www, 'manifest.webmanifest'), 'utf8')); eq(m.display, 'standalone'); ok(m.name && m.short_name && m.start_url);
  ok(m.icons.some(i => i.sizes === '192x192') && m.icons.some(i => i.sizes === '512x512') && m.icons.some(i => i.purpose === 'maskable')); for (const i of m.icons) ok(fs.existsSync(path.join(www, i.src)), i.src);
});
srv.kill(); done();
