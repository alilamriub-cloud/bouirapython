# JavaScript bridge methods are looked up by the WebView via reflection.
-keepclassmembers class dz.univbouira.pythonstudio.MainActivity$Bridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes JavascriptInterface
