import { makeRuntime } from './helpers/harness.mjs';
import { test, eq, ok, has, done } from './lib.mjs';

const run = (rt, code, files = {}) => rt.run({ code, filename: 'main.py', files: { 'main.py': code, ...files } });
const fresh = (log) => { log.out = ''; log.err = ''; log.plots = []; log.prompts = []; log.changes = {}; };

// ---------------------------------------------------------------- live mode (SharedArrayBuffer, blocking input)
{
  const answers = [];
  const { rt, log } = makeRuntime({ live: true, onNeed: (p, r) => r.submitInput(answers.length ? answers.shift() : '') });
  await rt.start();

  await test('1. print("Hello World")', async () => {
    const r = await run(rt, 'print("Hello World")'); ok(r.ok); eq(log.out, 'Hello World\n'); eq(rt.status, 'done');
  });
  await test('2. multiple input() prompts (the PDF example)', async () => {
    fresh(log); answers.push('Amina', '20', '3500.5');
    const code = 'name = input("Enter your name: ")\nage = int(input("Enter your age: "))\nsalary = float(input("Enter your salary: "))\nprint("Name:", name)\nprint("Age:", age)\nprint("Salary:", salary)';
    const r = await run(rt, code); ok(r.ok, log.err);
    eq(log.prompts.map(p => p.prompt), ['Enter your name: ', 'Enter your age: ', 'Enter your salary: ']);
    has(log.out, 'Enter your name: Amina\n'); has(log.out, 'Name: Amina\nAge: 20\nSalary: 3500.5\n'); eq(log.err, '');
  });
  await test('3. int(input()) / float(input()) arithmetic + no OSError', async () => {
    fresh(log); answers.push('7', '2.5');
    await run(rt, 'a=int(input("a? "))\nb=float(input("b? "))\nprint(a*b)'); has(log.out, '17.5'); ok(!log.err.includes('OSError'));
  });
  await test('3b. conversion error shows full traceback and recovers', async () => {
    fresh(log); answers.push('abc');
    const r = await run(rt, 'x = int(input("n: "))\nprint(x)'); ok(!r.ok); eq(rt.status, 'error');
    has(log.err, 'Traceback (most recent call last)'); has(log.err, 'File "main.py", line 1'); has(log.err, 'x = int(input("n: "))'); has(log.err, "ValueError: invalid literal for int() with base 10: 'abc'");
    fresh(log); const r2 = await run(rt, 'print("still alive")'); ok(r2.ok); has(log.out, 'still alive');
  });
  await test('4. input() inside while loop (login exercise) and for loop', async () => {
    fresh(log); answers.push('bad', 'worse', 'secret', '3', '4', '5');
    const code = 'tries = 0\nwhile input("Password: ") != "secret":\n    tries += 1\n    print("Wrong", tries)\nprint("Welcome")\ntotal = 0\nfor i in range(3):\n    total += int(input(f"n{i}: "))\nprint("total", total)';
    const r = await run(rt, code); ok(r.ok, log.err); has(log.out, 'Wrong 2'); has(log.out, 'Welcome'); has(log.out, 'total 12'); eq(log.prompts.length, 6);
  });
  await test('4b. empty input returns "" and getpass is flagged secret, not echoed', async () => {
    fresh(log); answers.push('', 'hunter2');
    await run(rt, 'import getpass\nv = input("x: ")\nprint(repr(v))\np = getpass.getpass("pw: ")\nprint(len(p))');
    has(log.out, "''"); has(log.out, 'pw: \n7'); ok(!log.out.includes('hunter2')); eq(log.prompts[1].secret, true); eq(log.prompts[0].secret, false);
  });
  await test('4c. sys.stdin.readline works', async () => {
    fresh(log); answers.push('line one');
    await run(rt, 'import sys\nprint(repr(sys.stdin.readline()))'); has(log.out, "'line one\\n'");
  });
  await test('15a. duplicate Run while running is rejected (no double execution)', async () => {
    fresh(log); answers.length = 0;
    const p1 = rt.run({ code: 'import time\nprint("A")', filename: 'main.py', files: {} });
    const r2 = await rt.run({ code: 'print("B")', filename: 'main.py', files: {} });
    eq(r2.rejected, true); await p1; ok(!log.out.includes('B'));
  });
  await test('5. syntax diagnostics (ast.parse) with line/column', async () => {
    eq(await rt.syntax('x = 1\nprint(x)'), []);
    const e = await rt.syntax('def f(:\n    pass'); eq(e.length, 1); eq(e[0].line, 1); ok(e[0].msg.length > 3);
    const e2 = await rt.syntax('if True:\nprint(1)'); has(e2[0].msg, 'indent'); eq(e2[0].line, 2);
  });
  await test('stdlib: statistics/random/itertools/collections/datetime/decimal/csv/json', async () => {
    fresh(log);
    const code = 'import statistics, random, itertools, collections, datetime, decimal, csv, json, io, math\nprint(statistics.mean([1,2,3,4]))\nprint(list(itertools.permutations([1,2,3]))[:2])\nprint(collections.Counter("aab"))\nprint(datetime.date(2024,2,29).isoformat())\nprint(decimal.Decimal("0.1")+decimal.Decimal("0.2"))\nprint(list(csv.reader(io.StringIO("a,b\\n1,2")))[1])\nprint(json.dumps({"k":[1,2]}))';
    const r = await run(rt, code); ok(r.ok, log.err); has(log.out, '2.5'); has(log.out, 'Counter({'); has(log.out, '0.3\n'); has(log.out, "['1', '2']"); has(log.out, '{"k": [1, 2]}');
  });
  await test('9. numpy + pandas load offline and work', async () => {
    fresh(log);
    const r = await run(rt, 'import numpy as np, pandas as pd\nprint(np.arange(10).mean())\nprint(pd.DataFrame({"a":[1,2,3]})["a"].sum())'); ok(r.ok, log.err); has(log.out, '4.5\n6\n');
  });
  await test('11. scipy.stats + sympy + statsmodels + sklearn + seaborn import', async () => {
    fresh(log);
    const code = 'from scipy import stats\nimport sympy as sp, statsmodels.api as sm, seaborn\nfrom sklearn.linear_model import LinearRegression\nimport numpy as np\nprint(round(stats.norm.cdf(1.96),4))\nx=sp.symbols("x"); print(sp.diff(x**2,x))\nm=LinearRegression().fit(np.array([[1],[2],[3]]),[2,4,6]); print(round(float(m.coef_[0]),3))\nprint(sm.__name__, seaborn.__version__)';
    const r = await run(rt, code); ok(r.ok, log.err); has(log.out, '0.975\n2*x\n2.0\n');
  });
  await test('12. matplotlib: PNG + SVG captured (normal curve, hist, bar, scatter, pie, box, heatmap)', async () => {
    fresh(log);
    const code = `import numpy as np, matplotlib.pyplot as plt, seaborn as sns, pandas as pd
x = np.linspace(-4, 4, 500); y = np.exp(-x**2 / 2) / np.sqrt(2*np.pi)
plt.plot(x, y); plt.title("Standard Normal Distribution"); plt.xlabel("Z"); plt.ylabel("Density"); plt.grid(True); plt.show()
plt.hist(np.random.default_rng(0).normal(size=200), bins=15); plt.show()
plt.bar(["a","b"],[1,2]); plt.show()
plt.scatter([1,2,3],[3,1,2]); plt.show()
plt.pie([1,2,3], labels=list("abc")); plt.show()
plt.boxplot([[1,2,3,4],[2,3,4,9]]); plt.show()
df = pd.DataFrame(np.random.default_rng(1).normal(size=(30,3)), columns=list("xyz"))
sns.heatmap(df.corr(), annot=True); plt.show()
plt.plot([1,2,3])  # not shown explicitly: still rendered at the end`;
    const r = await run(rt, code); ok(r.ok, log.err); eq(log.plots.length, 8);
    ok(Buffer.from(log.plots[0].png, 'base64').subarray(0, 4).toString('hex') === '89504e47', 'PNG signature'); has(log.plots[0].svg, '<svg');
  });
  await test('project files: import helper module, read+write files, changes reported', async () => {
    fresh(log);
    const main = 'import helper\nprint(helper.square(7))\nprint(open("data.txt").read().strip())\nwith open("out.txt","w") as f:\n    f.write("saved by program")\nimport pandas as pd\nprint(pd.read_csv("grades.csv")["g"].mean())';
    const r = await run(rt, main, { 'helper.py': 'def square(n):\n    return n*n\n', 'data.txt': 'hello file\n', 'grades.csv': 'g\n10\n20\n' });
    ok(r.ok, log.err); has(log.out, '49\nhello file\n15.0'); eq(log.changes['out.txt'], 'saved by program'); ok(!('data.txt' in log.changes));
    fresh(log); const r2 = await run(rt, 'import helper\nprint(helper.square(2))', { 'helper.py': 'def square(n):\n    return -1\n' }); has(log.out, '-1'); // module cache invalidated
  });
  await test('13. autocomplete from the live runtime (module + variable of last run)', async () => {
    fresh(log); await run(rt, 'import numpy as np, pandas as pd\ndf = pd.DataFrame({"a":[1]})\nlst=[1]');
    const np = await rt.complete({ module: 'numpy', path: [] }); ok(np.some(([n]) => n === 'linspace')); ok(np.some(([n, k]) => n === 'linalg' && k === 'module'));
    const rnd = await rt.complete({ module: 'numpy', path: ['random'] }); ok(rnd.some(([n]) => n === 'default_rng'));
    const df = await rt.complete({ var: 'df', path: [] }); ok(df.some(([n]) => n === 'groupby')); const l = await rt.complete({ var: 'lst', path: [] }); ok(l.some(([n]) => n === 'append'));
    eq(await rt.complete({ var: 'nope', path: [] }), null);
  });
  await test('formatter (autopep8)', async () => {
    const f = await rt.format('x=1\nif x==1 :\n  print( x )\n'); has(f, 'x = 1'); has(f, '    print(x)');
  });
  await test('15b. Stop an infinite loop (KeyboardInterrupt), then run again', async () => {
    fresh(log); const p = run(rt, 'print("start")\nwhile True:\n    pass');
    await new Promise(r => setTimeout(r, 1500)); const t0 = Date.now(); rt.stop(); const r = await p;
    eq(r.stopped, true); eq(rt.status, 'stopped'); has(log.err, 'KeyboardInterrupt'); ok(Date.now() - t0 < 2000, 'stopped quickly');
    fresh(log); const r2 = await run(rt, 'print("recovered")'); ok(r2.ok); has(log.out, 'recovered');
  });
  await test('15c. Stop while waiting for input()', async () => {
    fresh(log); const hold = []; rt.cb.needInput = (p) => hold.push(p);
    const p = run(rt, 'x = input("never answered: ")\nprint("unreachable")'); await new Promise(r => setTimeout(r, 1500)); eq(rt.status, 'waiting'); rt.stop(); const r = await p;
    eq(r.stopped, true); ok(!log.out.includes('unreachable')); fresh(log); rt.cb.needInput = undefined;
  });
  await test('Restart gives a clean interpreter', async () => {
    await run(rt, 'zzz = 123'); await rt.restart(); eq(rt.status, 'ready'); fresh(log); await run(rt, 'print("zzz" in globals())'); has(log.out, 'False');
  });
  rt.w.terminate();
}

// ---------------------------------------------------------------- compatibility (replay) mode: no SharedArrayBuffer
{
  const { rt, log } = makeRuntime({ live: false, answers: ['Karim', '41', '2.5'] });
  await rt.start();
  await test('compat mode: interactive input via replay gives the same result', async () => {
    eq(rt.live, false);
    const code = 'import random\nname = input("Name: ")\nage = int(input("Age: "))\nx = float(input("x: "))\nprint(name, age + 1, x * 2, random.random() < 2)';
    const r = await run(rt, code); ok(r.ok, log.err);
    eq(log.out, 'Name: Karim\nAge: 41\nx: 2.5\nKarim 42 5.0 True\n'); eq(log.resets, 3); eq(log.prompts.length, 3);
  });
  await test('compat mode: input in while loop', async () => {
    log.resets = 0; fresh(log); const a = ['no', 'no', 'yes']; rt.cb.needInput = (p) => setTimeout(() => rt.submitInput(a.shift()), 5);
    await run(rt, 'n = 0\nwhile input("ok? ") != "yes":\n    n += 1\nprint("tries", n)'); has(log.out, 'tries 2');
  });
  await test('compat mode: Stop restarts the worker and recovers', async () => {
    fresh(log); const p = run(rt, 'while True:\n    pass'); await new Promise(r => setTimeout(r, 1200)); rt.stop(); const r = await p; eq(r.stopped, true);
    await rt.readyPromise; fresh(log); const r2 = await run(rt, 'print("back")'); ok(r2.ok); has(log.out, 'back');
  });
  rt.w.terminate();
}
done();
