#!/usr/bin/env python3
"""Writes www/precache.json (list of files the service worker stores for offline use) and stamps a build id into www/sw.js."""
import hashlib, json, re, sys
from pathlib import Path

WWW = Path(__file__).resolve().parent.parent / "www"
SKIP = {"precache.json", ".DS_Store", "sw.js"}

files = sorted(p for p in WWW.rglob("*") if p.is_file() and p.name not in SKIP and not p.name.endswith(".map"))
h = hashlib.sha1()
for p in files:
    rel = p.relative_to(WWW).as_posix()
    h.update(rel.encode())
    h.update(str(p.stat().st_size).encode() if rel.startswith("pyodide/") else p.read_bytes())
build = h.hexdigest()[:10]
files.sort(key=lambda p: (p.stat().st_size, p.name))                      # small files first: the app becomes usable early
lst = [p.relative_to(WWW).as_posix() for p in files] + ["sw.js"]
(WWW / "precache.json").write_text(json.dumps({"build": build, "bytes": sum(p.stat().st_size for p in files), "files": lst}))
sw = (WWW / "sw.js").read_text()
sw = re.sub(r"const BUILD = '[^']*';", f"const BUILD = '{build}';", sw)
(WWW / "sw.js").write_text(sw)
print(f"precache.json: {len(lst)} files, {sum(p.stat().st_size for p in files)/1e6:.1f} MB, build {build}")
